"use client";

import { useState } from "react";
import { Sidebar } from "@/components/maduro/sidebar";
import { ChatWindow } from "@/components/maduro/chat-window";
import { ProfilePanel } from "@/components/maduro/profile-panel";
import { FaceToFace } from "@/components/maduro/face-to-face";
import { motion, AnimatePresence } from "framer-motion";

export default function Home() {
  const [view, setView] = useState<"chat" | "face-to-face">("chat");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen w-full bg-[#0a0a0a] text-zinc-100 overflow-hidden font-sans">
      {/* Sidebar */}
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} activeView={view} setView={setView} />

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col relative overflow-hidden">
        <AnimatePresence mode="wait">
          {view === "chat" ? (
            <motion.div
              key="chat"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex-1 flex overflow-hidden"
            >
              <ChatWindow onFaceClick={() => setView("face-to-face")} />
              <ProfilePanel />
            </motion.div>
          ) : (
            <motion.div
              key="face-to-face"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
              className="flex-1"
            >
              <FaceToFace onBack={() => setView("chat")} />
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
