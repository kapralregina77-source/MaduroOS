"use client";

import { motion } from "framer-motion";
import { 
  Terminal, 
  Mic, 
  History, 
  Settings, 
  Plus, 
  ChevronLeft, 
  ChevronRight,
  User,
  ShieldAlert,
  LayoutDashboard
} from "lucide-react";
import { cn } from "@/lib/utils";

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (open: boolean) => void;
  activeView: "chat" | "face-to-face";
  setView: (view: "chat" | "face-to-face") => void;
}

export function Sidebar({ isOpen, setIsOpen, activeView, setView }: SidebarProps) {
  const navItems = [
    { id: "chat", icon: Terminal, label: "Terminal" },
    { id: "face-to-face", icon: Mic, label: "Face Sync" },
    { id: "dashboard", icon: LayoutDashboard, label: "State Monitor" },
    { id: "history", icon: History, label: "Archives" },
  ];

  return (
    <motion.aside
      initial={false}
      animate={{ width: isOpen ? 260 : 64 }}
      className="h-full bg-[#050505] border-r border-zinc-900 flex flex-col z-50 relative"
    >
      {/* Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-zinc-900 bg-black/40">
        <div className={cn("flex items-center gap-3 transition-opacity duration-300", !isOpen && "opacity-0 invisible absolute")}>
          <div className="w-8 h-8 bg-zinc-800 flex items-center justify-center">
             <ShieldAlert size={18} className="text-yellow-500" />
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] font-black tracking-[0.2em] text-white leading-none">MADURO_OS</span>
            <span className="text-[8px] font-bold text-zinc-500 tracking-tighter uppercase mt-0.5">National Security Node</span>
          </div>
        </div>
        <button 
          onClick={() => setIsOpen(!isOpen)}
          className="text-zinc-500 hover:text-white p-1.5 hover:bg-zinc-900 transition-all rounded-sm"
        >
          {isOpen ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
        </button>
      </div>

      {/* System Pulse */}
      {isOpen && (
        <div className="px-5 py-3 border-b border-zinc-900 flex items-center gap-2">
          <div className="flex gap-0.5">
            {[1, 2, 3].map(i => (
              <motion.div 
                key={i}
                animate={{ height: [4, 12, 4], opacity: [0.3, 1, 0.3] }}
                transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                className="w-1 bg-yellow-500 rounded-full"
              />
            ))}
          </div>
          <span className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest">System Operational // Level 4</span>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-6 flex flex-col gap-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => (item.id === "chat" || item.id === "face-to-face") && setView(item.id as any)}
            className={cn(
              "flex items-center gap-3 px-3 py-2.5 transition-all group relative border border-transparent rounded-sm",
              (activeView === item.id) 
                ? "bg-zinc-900 text-white border-zinc-800 shadow-[0_4px_12px_rgba(0,0,0,0.5)]" 
                : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-950"
            )}
          >
            <item.icon size={18} className={cn(activeView === item.id ? "text-yellow-500" : "group-hover:text-zinc-300")} />
            {isOpen && <span className="text-[11px] font-bold tracking-wide uppercase">{item.label}</span>}
            {activeView === item.id && !isOpen && <div className="absolute right-0 w-1 h-4 bg-yellow-500 rounded-l-full" />}
          </button>
        ))}
        
        <div className="mt-8 px-3">
           <button className="flex items-center gap-3 w-full p-2 border border-zinc-800 border-dashed hover:border-zinc-600 hover:bg-zinc-900/50 transition-all text-zinc-500 hover:text-zinc-300 rounded-sm group">
              <Plus size={16} />
              {isOpen && <span className="text-[10px] font-bold uppercase tracking-tight">New Deployment</span>}
           </button>
        </div>
      </nav>

      {/* Footer */}
      <div className="p-4 border-t border-zinc-900 bg-black/20 flex flex-col gap-4">
        <button className="flex items-center gap-3 px-1 text-zinc-500 hover:text-white transition-all group">
          <Settings size={18} />
          {isOpen && <span className="text-[10px] font-bold tracking-widest uppercase">Preferences</span>}
        </button>
        <div className="flex items-center gap-3 px-1 py-1 bg-zinc-900/40 border border-zinc-900 rounded-sm">
          <div className="w-8 h-8 bg-zinc-800 flex items-center justify-center overflow-hidden border border-zinc-700">
            <User size={16} className="text-zinc-300" />
          </div>
          {isOpen && (
            <div className="flex flex-col overflow-hidden">
              <span className="text-[11px] font-black truncate text-white uppercase tracking-tight">Admin_01</span>
              <span className="text-[8px] text-yellow-500/70 font-bold uppercase tracking-tighter">Clearance: Level 9</span>
            </div>
          )}
        </div>
      </div>
    </motion.aside>
  );
}
