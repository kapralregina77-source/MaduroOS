"use client";

import { motion, AnimatePresence } from "framer-motion";
import { 
  X, 
  Mic, 
  MicOff, 
  Settings, 
  Maximize2, 
  Volume2,
  PhoneOff,
  Shield,
  Zap,
  Activity,
  ChevronRight,
  Database,
  Wifi
} from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

interface FaceToFaceProps {
  onBack: () => void;
}

export function FaceToFace({ onBack }: FaceToFaceProps) {
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [uptime, setUptime] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setUptime(u => u + 1), 1000);
    const speaker = setInterval(() => setIsSpeaking(prev => !prev), 3000);
    return () => {
      clearInterval(timer);
      clearInterval(speaker);
    };
  }, []);

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="relative h-full w-full bg-[#050505] flex flex-col overflow-hidden group">
      {/* Background Layer */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <motion.img 
          initial={{ scale: 1.1, filter: "grayscale(100%) brightness(0.5)" }}
          animate={{ 
            scale: isSpeaking ? 1.05 : 1.1,
            filter: isSpeaking ? "grayscale(80%) brightness(0.6)" : "grayscale(100%) brightness(0.5)"
          }}
          transition={{ duration: 4, repeat: Infinity, repeatType: "reverse" }}
          src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1000&auto=format&fit=crop" 
          alt="Maduro Feed"
          className="w-full h-full object-cover transition-all"
        />
        
        {/* HUD Grid Overlay */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:40px_40px]" />
        
        {/* Vignette */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#000000_100%)]" />
      </div>

      {/* Top HUD Bar */}
      <div className="relative z-10 p-8 flex items-start justify-between">
        <div className="flex flex-col gap-4">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-zinc-900 border border-zinc-800 p-1">
               <div className="w-full h-full border border-yellow-500/50 flex items-center justify-center relative">
                  <Activity size={20} className="text-yellow-500" />
                  <div className="absolute -top-1 -right-1 w-2 h-2 bg-yellow-500 rounded-full animate-ping" />
               </div>
            </div>
            <div>
              <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">Nicolás Maduro</h2>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-[10px] font-mono text-yellow-500 uppercase tracking-widest">Target_Link: Established</span>
                <span className="text-zinc-700 text-[10px]">//</span>
                <span className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">Uptime: {formatTime(uptime)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex gap-2">
             {["VOICE_SYNC", "EYE_LOCK", "SECURE_PKI"].map(tag => (
                <div key={tag} className="px-2 py-0.5 bg-zinc-900/50 border border-zinc-800 rounded-sm text-[8px] font-bold text-zinc-500 tracking-tighter uppercase">
                   {tag}
                </div>
             ))}
          </div>
        </div>

        <div className="flex flex-col items-end gap-2">
          <button 
            onClick={onBack}
            className="group flex items-center gap-3 px-4 py-2 bg-zinc-900/80 border border-zinc-800 hover:bg-zinc-800 transition-all rounded-sm"
          >
            <span className="text-[9px] font-black text-zinc-400 uppercase tracking-widest group-hover:text-white">Terminate_Session</span>
            <X size={14} className="text-zinc-500 group-hover:text-red-500" />
          </button>
          <div className="text-[8px] font-mono text-zinc-600 uppercase tracking-widest">
             Ref_Node: VZ-CAR-NODE-04
          </div>
        </div>
      </div>

      {/* Center Visualizers */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center">
        {/* Central HUD Ring */}
        <div className="relative w-80 h-80 flex items-center justify-center">
           <motion.div 
             animate={{ rotate: 360 }}
             transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
             className="absolute inset-0 border-2 border-dashed border-zinc-800 rounded-full"
           />
           <motion.div 
             animate={{ rotate: -360 }}
             transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
             className="absolute inset-4 border border-zinc-900 border-t-yellow-500/30 rounded-full"
           />
           
           <div className="flex items-center gap-1.5 h-20">
            {[...Array(12)].map((_, i) => (
              <motion.div
                key={i}
                initial={{ height: 4 }}
                animate={{ 
                  height: isSpeaking ? [4, Math.random() * 60 + 20, 4] : 4 
                }}
                transition={{ 
                  duration: 0.4, 
                  repeat: Infinity, 
                  delay: i * 0.05 
                }}
                className="w-1.5 bg-yellow-500/80 rounded-full shadow-[0_0_15px_rgba(234,179,8,0.4)]"
              />
            ))}
          </div>
        </div>
        
        <div className="mt-12 flex flex-col items-center gap-4">
           <div className="flex items-center gap-8">
              <div className="flex flex-col items-center">
                 <span className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest mb-2">Vocal_Stress</span>
                 <div className="w-24 h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                    <motion.div 
                      animate={{ width: isSpeaking ? "65%" : "20%" }}
                      className="h-full bg-yellow-500/50" 
                    />
                 </div>
              </div>
              <div className="flex flex-col items-center">
                 <span className="text-[9px] font-bold text-zinc-600 uppercase tracking-widest mb-2">Sync_Confidence</span>
                 <div className="w-24 h-1.5 bg-zinc-900 rounded-full overflow-hidden">
                    <motion.div 
                      animate={{ width: "98%" }}
                      className="h-full bg-zinc-500" 
                    />
                 </div>
              </div>
           </div>
           <p className="text-zinc-500 text-[10px] font-mono tracking-[0.4em] uppercase animate-pulse">
            {isSpeaking ? "Neural Response Generating..." : "Standby for Directive"}
          </p>
        </div>
      </div>

      {/* Footer Controls */}
      <div className="relative z-10 p-12 bg-gradient-to-t from-black to-transparent">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
             <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                   <Wifi size={12} className="text-yellow-500" />
                   <span className="text-[10px] font-black text-white uppercase tracking-widest">Uplink: Stable</span>
                </div>
                <div className="flex items-center gap-2">
                   <Database size={12} className="text-zinc-600" />
                   <span className="text-[10px] font-black text-zinc-600 uppercase tracking-widest">Buffer: 4.2ms</span>
                </div>
             </div>
          </div>

          <div className="flex items-center gap-8">
            <button className="w-14 h-14 bg-zinc-900/50 border border-zinc-800 hover:border-zinc-600 transition-all rounded-sm flex items-center justify-center group">
              <Settings size={20} className="text-zinc-500 group-hover:text-white" />
            </button>
            
            <button 
              onClick={() => setIsMuted(!isMuted)}
              className={cn(
                "w-20 h-20 rounded-sm border-2 transition-all flex items-center justify-center relative overflow-hidden group",
                isMuted 
                  ? "bg-red-500/10 border-red-500 text-red-500" 
                  : "bg-zinc-900 border-zinc-800 text-white hover:border-yellow-500"
              )}
            >
              <div className="relative z-10">
                {isMuted ? <MicOff size={32} /> : <Mic size={32} />}
              </div>
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>

            <button 
              onClick={onBack}
              className="w-14 h-14 bg-zinc-900/50 border border-zinc-800 hover:border-red-500/50 transition-all rounded-sm flex items-center justify-center group"
            >
              <PhoneOff size={20} className="text-zinc-500 group-hover:text-red-500" />
            </button>
          </div>

          <div className="hidden lg:flex flex-col items-end gap-1">
             <div className="flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className={cn("w-4 h-1 rounded-full", i < 4 ? "bg-yellow-500" : "bg-zinc-800")} />
                ))}
             </div>
             <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Signal_Integrity</span>
          </div>
        </div>
      </div>

      {/* Edge Vignette / Scanline Effect */}
      <div className="absolute inset-0 pointer-events-none z-20">
         <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.1)_50%)] bg-[size:100%_4px]" />
         <div className="absolute inset-0 border-[40px] border-black/20 pointer-events-none" style={{ maskImage: 'radial-gradient(circle, transparent 70%, black 100%)' }} />
      </div>
    </div>
  );
}
