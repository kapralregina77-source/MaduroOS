"use client";

import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  Send, 
  Terminal as TerminalIcon,
  Maximize2,
  Volume2,
  Activity,
  Shield,
  Zap,
  Lock,
  Wifi,
  Database
} from "lucide-react";
import { cn } from "@/lib/utils";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

interface ChatWindowProps {
  onFaceClick: () => void;
}

export function ChatWindow({ onFaceClick }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content: "MADURO_OS Secure Node initialized. All transmissions are encrypted via AES-256. Awaiting directive.",
      timestamp: new Date(),
    }
  ]);
  const [input, setInput] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim()) return;
    
    const userMsg: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };
    
    setMessages(prev => [...prev, userMsg]);
    setInput("");

    // Simulate AI response
    setTimeout(() => {
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: "DIRECTIVE_RECEIVED: Entendido. Estamos procesando la solicitud a través del núcleo central. El Poder Popular tecnológico avanza sin descanso.",
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMsg]);
    }, 800);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050505] relative overflow-hidden">
      {/* OS Toolbar */}
      <header className="h-14 border-b border-zinc-900 flex items-center justify-between px-6 bg-black/60 backdrop-blur-md z-10">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-yellow-500 rounded-full animate-pulse" />
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-white">Live_Session: Alpha-7</span>
          </div>
          <div className="hidden md:flex items-center gap-4 text-zinc-500">
             <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest">
               <Shield size={10} className="text-zinc-600" /> Secure
             </div>
             <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest">
               <Wifi size={10} className="text-zinc-600" /> Latency: 12ms
             </div>
             <div className="flex items-center gap-1.5 text-[9px] font-bold uppercase tracking-widest">
               <Database size={10} className="text-zinc-600" /> Storage: Optimal
             </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={onFaceClick} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-900/50 border border-zinc-800 hover:bg-zinc-800 transition-all rounded-sm group">
            <Maximize2 size={12} className="text-zinc-400 group-hover:text-yellow-500" />
            <span className="text-[9px] font-bold text-zinc-400 uppercase tracking-widest group-hover:text-white">Face_Sync</span>
          </button>
          <div className="h-4 w-[1px] bg-zinc-800" />
          <Lock size={14} className="text-zinc-600" />
        </div>
      </header>

      {/* Terminal Viewport */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-8 space-y-8 scrollbar-hide bg-transparent relative"
      >
        <div className="max-w-3xl mx-auto">
          <div className="mb-12 border-l border-zinc-800 pl-6 py-2">
            <p className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest leading-loose">
              [SYSTEM_BOOT] ... OK<br/>
              [CORE_ID] MAD-OS-01<br/>
              [AUTH_STATUS] CLEARANCE_GRANTED<br/>
              [READY]
            </p>
          </div>

          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex flex-col gap-3 group mb-8"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-1.5 h-1.5 rounded-full",
                      msg.role === "user" ? "bg-zinc-500" : "bg-yellow-500"
                    )} />
                    <span className={cn(
                      "text-[10px] font-black uppercase tracking-[0.2em]",
                      msg.role === "user" ? "text-zinc-400" : "text-white"
                    )}>
                      {msg.role === "user" ? "Admin@Local" : "Maduro@Sys"}
                    </span>
                  </div>
                  <span className="text-[8px] font-mono text-zinc-600 uppercase">
                    T+ {msg.timestamp.toLocaleTimeString([], { hour12: false })}
                  </span>
                </div>
                <div className={cn(
                  "text-sm leading-relaxed p-5 border border-zinc-900 rounded-sm relative group-hover:border-zinc-800 transition-all",
                  msg.role === "user" ? "bg-zinc-900/20 text-zinc-300" : "bg-zinc-900/40 text-white shadow-[0_8px_24px_rgba(0,0,0,0.5)]"
                )}>
                  {msg.content}
                  {msg.role === "assistant" && (
                     <div className="absolute -left-[1px] top-0 bottom-0 w-1 bg-yellow-500" />
                  )}
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Command Input Area */}
      <div className="p-8 bg-black/40 border-t border-zinc-900">
        <div className="max-w-3xl mx-auto">
          <div className="relative group bg-zinc-900/40 border border-zinc-800 hover:border-zinc-700 transition-all rounded-sm">
            <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-3 pointer-events-none">
              <span className="text-yellow-500 font-mono text-sm">{`>`}</span>
            </div>
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  handleSend();
                }
              }}
              placeholder="Enter system command..."
              className="w-full bg-transparent border-none focus:ring-0 text-sm py-4 pl-10 pr-24 text-white placeholder:text-zinc-600 outline-none"
              autoFocus
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-2">
              <button 
                onClick={handleSend}
                disabled={!input.trim()}
                className={cn(
                  "flex items-center gap-2 text-[9px] font-black px-4 py-2 transition-all rounded-sm uppercase tracking-widest",
                  input.trim() 
                    ? "bg-yellow-500 text-black hover:bg-yellow-400" 
                    : "bg-zinc-800 text-zinc-600"
                )}
              >
                Execute <Send size={10} />
              </button>
            </div>
          </div>
          <div className="mt-3 flex items-center justify-between px-1">
             <p className="text-[8px] text-zinc-600 font-bold uppercase tracking-[0.2em]">
                System_Prompt: Standard // Protocol: Secure_Chat_v4
             </p>
             <div className="flex gap-2">
                {[1, 2, 3].map(i => <div key={i} className="w-1 h-1 bg-zinc-800 rounded-full" />)}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}
