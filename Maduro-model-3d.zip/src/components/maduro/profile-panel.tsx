"use client";

import { motion } from "framer-motion";
import { 
  Info, 
  Settings, 
  Share2, 
  Flag, 
  Star,
  Globe,
  Lock,
  Zap,
  ChevronRight,
  Shield,
  Activity,
  Cpu,
  Database
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export function ProfilePanel() {
  return (
    <aside className="w-80 border-l border-zinc-900 bg-[#050505] hidden xl:flex flex-col overflow-y-auto relative z-10">
      <div className="p-8 flex flex-col items-center">
        <div className="relative mb-6">
          <div className="w-32 h-32 bg-zinc-900 border border-zinc-800 p-1">
             <div className="w-full h-full border border-yellow-500/30 overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=256&h=256&auto=format&fit=crop" 
                  alt="Maduro AI"
                  className="w-full h-full object-cover grayscale brightness-75"
                />
                <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.2)_50%)] bg-[size:100%_4px] pointer-events-none" />
             </div>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-yellow-500 text-black px-2 py-0.5 text-[8px] font-black uppercase tracking-widest border border-black">
             Online
          </div>
        </div>

        <div className="text-center w-full">
          <h2 className="text-sm font-black text-white uppercase tracking-[0.3em]">Nicolás Maduro</h2>
          <div className="flex items-center justify-center gap-2 mt-2">
             <div className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse" />
             <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">Digital_Avatar v4.12</span>
          </div>
        </div>
        
        <div className="flex gap-2 mt-8 w-full">
          <button className="flex-1 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-400 hover:text-white transition-all py-2 text-[9px] font-black uppercase tracking-widest rounded-sm">
            Deploy
          </button>
          <button className="flex-1 bg-yellow-500 text-black hover:bg-yellow-400 transition-all py-2 text-[9px] font-black uppercase tracking-widest rounded-sm shadow-[0_0_15px_rgba(234,179,8,0.2)]">
            Archive
          </button>
        </div>
      </div>

      <div className="px-8 pb-8 space-y-8">
        <section>
          <div className="flex items-center gap-2 mb-4">
             <Info size={12} className="text-yellow-500" />
             <h3 className="text-[10px] text-zinc-400 uppercase tracking-[0.2em] font-black">Entity Metadata</h3>
          </div>
          <p className="text-[11px] text-zinc-500 leading-relaxed font-medium">
            Entidad soberana digital procesada a través del Núcleo de Inteligencia Popular. Especializado en geopolítica bolivariana y retórica del siglo XXI.
          </p>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-2 mb-4">
             <Activity size={12} className="text-yellow-500" />
             <h3 className="text-[10px] text-zinc-400 uppercase tracking-[0.2em] font-black">Core Diagnostics</h3>
          </div>
          <div className="grid grid-cols-1 gap-3">
            {[
              { label: "Neural Load", value: "24.2%", icon: Cpu, color: "text-zinc-500" },
              { label: "Sync Confidence", value: "98.8%", icon: Shield, color: "text-zinc-500" },
              { label: "Archive Size", value: "1.2 PB", icon: Database, color: "text-zinc-500" },
            ].map((stat) => (
              <div key={stat.label} className="p-3 bg-zinc-900/40 border border-zinc-900 rounded-sm flex items-center justify-between group hover:border-zinc-800 transition-all">
                <div className="flex items-center gap-3">
                  <stat.icon size={14} className="text-zinc-600 group-hover:text-yellow-500 transition-colors" />
                  <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">{stat.label}</span>
                </div>
                <span className="text-[10px] font-mono text-zinc-400 group-hover:text-white transition-colors">{stat.value}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <div className="flex items-center gap-2 mb-4">
             <Settings size={12} className="text-yellow-500" />
             <h3 className="text-[10px] text-zinc-400 uppercase tracking-[0.2em] font-black">I/O Protocols</h3>
          </div>
          <button className="w-full flex items-center justify-between p-3 bg-zinc-900/20 border border-zinc-900 hover:bg-zinc-900/50 hover:border-zinc-800 transition-all group">
            <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest group-hover:text-zinc-300">Vocal_Profile</span>
            <span className="text-[9px] font-mono text-zinc-600">Standard</span>
          </button>
          <button className="w-full flex items-center justify-between p-3 bg-zinc-900/20 border border-zinc-900 hover:bg-zinc-900/50 hover:border-zinc-800 transition-all group">
            <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest group-hover:text-zinc-300">Tone_Matrix</span>
            <span className="text-[9px] font-mono text-zinc-600">Leader</span>
          </button>
        </section>
      </div>

      <div className="mt-auto p-8 border-t border-zinc-900">
        <button className="flex items-center justify-center gap-2 w-full py-3 bg-red-500/5 border border-red-500/20 text-red-500/50 hover:text-red-500 hover:bg-red-500/10 transition-all text-[9px] font-black uppercase tracking-widest rounded-sm">
          <Flag size={12} /> Flag_Transmission
        </button>
      </div>
    </aside>
  );
}
